# Importa os modulos
import os

# Limpa o CMD
if os.name == "nt":
    os.system("@cls & @title Heartstealer DDOS Tool by: VVQUA & TXKHAI e")
else:
    os.system("clear")
