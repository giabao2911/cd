

Just install python 3.8 and download this repository.

You will then need to install the requirements (requirements.txt) and execute main.py.

0. Install Python (3.8) (3.6 should work as well.) (On windows, make sure to enable add to PATH.)

1. Download Zip

2. Unzip

3. Open terminal in the Raven-Storm folder. (On windows you should be able to just right click the folder while holding down the shift key, you can then click on open in Powershell (administrator).)

4. Install the requirements.

`pip install -r requirements.txt`

5. Execute Raven-Storm.

`python main.py`

(You might need to add a 3 directly after python and pip.)
